-------------------Bumble's Comms System!-------------------

Thank you for purchasing bComms, the install instructions are listed below and on the addon page.

-------------------HOW TO INSTALL-------------------

To install bComms, simply place the folder labelled "bcomms-system" into your "garrysmod/addons" folder and restart your server!

The config is located in "garrysmod/addons/bcomms-system/lua/autorun" both files are used for configuration.