net.Receive("comms_addon", function()
local tableread = net.ReadTable()
local nick = tableread.player:Nick()
chat.AddText( Color(173, 169, 52), "[COMMS] ", Color( 230, 230, 230, 255), nick, ": ", Color( 255, 255, 255, 255), tableread.message )
end)

net.Receive("error_message", function()
    chat.AddText( Color(207, 106, 99, 255), "[Error] ", Color(255, 255, 255, 255), "You need to specify a message" ) -- Error message when a user doesn't submit a message after "/comms"
end)